local M = {}
-----------------------------------------------------------
-- Constants
-----------------------------------------------------------
M.FILETYPE = "toggleterm"
-- -30 is a magic number based on manual testing of what looks good
M.shading_amount = -30
-- Highlight group name prefix
M.highlight_group_name_prefix = "ToggleTerm"

return M
