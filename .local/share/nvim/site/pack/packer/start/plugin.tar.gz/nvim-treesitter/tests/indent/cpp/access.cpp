class Foo {
public:
    int x;
private:
    int y;
};
