require('cmp').register_source('vsnip', require('cmp_vsnip').new())
