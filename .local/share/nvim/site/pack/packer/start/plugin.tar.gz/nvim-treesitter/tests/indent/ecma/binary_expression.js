if_this_is_correct &&
  run_this_thing()
    .filter()
    .map()
