describe("simple nvim test", function()
  it("should work", function()
    vim.cmd "let g:val = v:true"
  end)
end)
