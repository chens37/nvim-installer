// https://github.com/nvim-treesitter/nvim-treesitter/issues/2571
class Testo {
  void foo() {
    System.out.println("foo");
  }
}
